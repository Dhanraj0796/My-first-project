<?php
/**
 * PHP Phone Book
 * @Version: 1.0
 * @Author: ramin moradi . github.com/ramoures
 * @Email: ramoures@gmail.com
 * @License: MIT
*/
require_once 'init.php';
?>