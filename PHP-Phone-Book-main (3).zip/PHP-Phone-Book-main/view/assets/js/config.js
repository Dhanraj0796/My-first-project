export const MAX_PHONE_NUMBER_TO_BE_ADD = "7";
export const COOKIE_NAME_FOR_BACKEND_LANG = "phone_book_b_lang";
export const COOKIE_NAME_FOR_FRONTEND_LANG = "phone_book_lang";
