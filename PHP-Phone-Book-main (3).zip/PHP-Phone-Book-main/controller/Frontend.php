<?php
abstract class Frontend extends Base{
    public function __construct($param) {
        parent::__construct($param);
    }
}
?>