<?php
class HomeModel extends Models{
    // Ready for development
}
?>