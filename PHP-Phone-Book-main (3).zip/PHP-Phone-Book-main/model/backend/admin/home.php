<?php
class AdminModel extends Models{
    // Ready for development
}
?>