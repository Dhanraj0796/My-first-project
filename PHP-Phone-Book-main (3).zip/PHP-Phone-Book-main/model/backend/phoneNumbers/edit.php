<?php
class EditPhoneNumbersModel extends Models{
    // Ready for development
}
?>