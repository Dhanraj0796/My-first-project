<?php
class ProfileModel extends Models{
    // Ready for development
}

?>